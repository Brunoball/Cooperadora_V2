export { default } from "./ModalComprobantePago";
